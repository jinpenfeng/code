% Please change your working directory before running these codes
clear all;
clc;
Z = csvread('TCI_long_QQRcoef.csv', 1, 0);
[m,n] = size(Z);
m = 1 : m;
n = 1 : n;
num = size(m);
m = m ./ (num(2) + 1);
n = n ./ (num(2) + 1);
colormap jet; % set color layout, you can slso choose hsv, hot, cool, spring, summer, autumn, winner, gray
surf(m, n, Z);
xlabel('Quantile of TCI'); % your dependent variable
ylabel('Quantile of GCD'); % your independent variable
title('Impact of GCD on TCI')
colorbar